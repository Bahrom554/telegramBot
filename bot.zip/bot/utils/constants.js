

exports.commands = {
    login:'login',
    email_create:'email_create',
    passwor_create:'passwor_create',
    two_steps_list:'two_steps_list', 
    two_step_password_created:"two_step_password_created"



    }
    exports.callback_commands = {
        email_created_sucess:'email_create_sucess', 
        email_created_wrong:'email_create_wrong',
        password_created_sucess:'password_created_sucess',
        password_created_wrong:'password_created_wrong',
        two_step_password_sucess:'two_step_password_sucess',
        two_step_password_wrong:'two_step_password_wrong'
        
    
        }
exports.message = {
    after_email_sucess_given_name:"GV"
}